"""Gemini Image Generation tools for Meta Ads MCP.

Provides two tools:
- generate_image: Generate an image via Google Gemini and save to disk
- generate_and_upload_ad_image: Generate via Gemini + upload to Meta Ads account
"""

import json
import os
import base64
import time
from typing import Optional

from .server import mcp_server
from .api import meta_api_tool, make_api_request
from .utils import logger


def _get_gemini_client():
    """Create a Gemini client from environment variable."""
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY environment variable is not set. "
            "Add it to the MCP server env vars: -e GEMINI_API_KEY=your_key"
        )
    from google import genai
    return genai.Client(api_key=api_key)


def _generate_image_bytes(client, prompt: str, aspect_ratio: str, model: str) -> bytes:
    """Call Gemini API and return raw image bytes."""
    from google.genai import types

    config = types.GenerateContentConfig(
        response_modalities=["IMAGE"],
        image_config=types.ImageConfig(
            aspect_ratio=aspect_ratio,
        ),
    )

    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config=config,
    )

    # Extract image bytes from response
    if not response.candidates:
        raise RuntimeError("Gemini returned no candidates")

    for part in response.candidates[0].content.parts:
        if part.inline_data and part.inline_data.data:
            return part.inline_data.data

    raise RuntimeError("Gemini response contained no image data")


@mcp_server.tool()
async def generate_image(
    prompt: str,
    output_path: Optional[str] = None,
    aspect_ratio: Optional[str] = None,
    model: Optional[str] = None,
) -> str:
    """
    Generate an image using Google Gemini and save it to disk.

    Args:
        prompt: Text description of the image to generate
        output_path: File path to save the image (default: /tmp/gemini_<timestamp>.png)
        aspect_ratio: Aspect ratio - "1:1", "16:9", "9:16", "4:3", "3:4" (default: "1:1")
        model: Gemini model - "gemini-2.5-flash-image" (fast, ~$0.04) or "gemini-3-pro-image-preview" (quality, ~$0.13). Default: gemini-2.5-flash-image

    Returns:
        JSON with success status, file_path, model used, prompt and aspect_ratio
    """
    try:
        effective_model = model or "gemini-2.5-flash-image"
        effective_ratio = aspect_ratio or "1:1"
        effective_path = output_path or f"/tmp/gemini_{int(time.time())}.png"

        logger.info(f"Generating image with Gemini: model={effective_model}, ratio={effective_ratio}")
        logger.debug(f"Prompt: {prompt}")

        client = _get_gemini_client()
        image_bytes = _generate_image_bytes(client, prompt, effective_ratio, effective_model)

        # Ensure output directory exists
        os.makedirs(os.path.dirname(effective_path) or ".", exist_ok=True)

        with open(effective_path, "wb") as f:
            f.write(image_bytes)

        file_size = len(image_bytes)
        logger.info(f"Image saved to {effective_path} ({file_size} bytes)")

        return json.dumps({
            "success": True,
            "file_path": effective_path,
            "file_size_bytes": file_size,
            "model": effective_model,
            "prompt": prompt,
            "aspect_ratio": effective_ratio,
        }, indent=2)

    except Exception as e:
        logger.error(f"Gemini image generation failed: {e}")
        return json.dumps({
            "success": False,
            "error": str(e),
            "prompt": prompt,
            "model": model or "gemini-2.5-flash-image",
        }, indent=2)


@mcp_server.tool()
@meta_api_tool
async def generate_and_upload_ad_image(
    account_id: str,
    prompt: str,
    name: Optional[str] = None,
    aspect_ratio: Optional[str] = None,
    model: Optional[str] = None,
    access_token: Optional[str] = None,
) -> str:
    """
    Generate an image using Google Gemini and upload it directly to a Meta Ads account.

    Args:
        account_id: Meta Ads account ID (format: act_XXXXXXXXX)
        prompt: Text description of the image to generate
        name: Name for the image in Meta Ads (default: auto-generated from prompt)
        aspect_ratio: Aspect ratio - "1:1", "16:9", "9:16", "4:3", "3:4" (default: "1:1")
        model: Gemini model - "gemini-2.5-flash-image" (fast) or "gemini-3-pro-image-preview" (quality). Default: gemini-2.5-flash-image
        access_token: Meta API access token (optional - uses cached token if not provided)

    Returns:
        JSON with image_hash ready for use in create_ad_creative
    """
    if not account_id:
        return json.dumps({"error": "No account_id provided"}, indent=2)

    if not account_id.startswith("act_"):
        account_id = f"act_{account_id}"

    effective_model = model or "gemini-2.5-flash-image"
    effective_ratio = aspect_ratio or "1:1"

    # Step 1: Generate image via Gemini
    logger.info(f"Generating image for Meta Ads upload: model={effective_model}, ratio={effective_ratio}")

    client = _get_gemini_client()
    image_bytes = _generate_image_bytes(client, prompt, effective_ratio, effective_model)

    logger.info(f"Image generated ({len(image_bytes)} bytes), uploading to Meta Ads...")

    # Step 2: Encode to base64 and upload to Meta
    encoded_image = base64.b64encode(image_bytes).decode("utf-8")
    final_name = name or f"gemini_{effective_model}_{int(time.time())}.png"

    endpoint = f"{account_id}/adimages"
    params = {
        "bytes": encoded_image,
        "name": final_name,
    }

    data = await make_api_request(endpoint, access_token, params, method="POST")

    # Parse Meta API response to extract image_hash
    if isinstance(data, dict) and "images" in data and isinstance(data["images"], dict) and data["images"]:
        images_dict = data["images"]
        images_list = []
        for hash_key, info in images_dict.items():
            normalized = {
                "hash": info.get("hash") or hash_key,
                "url": info.get("url"),
                "width": info.get("width"),
                "height": info.get("height"),
                "name": info.get("name"),
            }
            normalized = {k: v for k, v in normalized.items() if v is not None}
            images_list.append(normalized)

        images_list.sort(key=lambda i: i.get("hash", ""))
        primary_hash = images_list[0].get("hash") if images_list else None

        return json.dumps({
            "success": True,
            "account_id": account_id,
            "image_hash": primary_hash,
            "image_name": final_name,
            "gemini_model": effective_model,
            "aspect_ratio": effective_ratio,
            "prompt": prompt,
            "images": images_list,
        }, indent=2)

    if isinstance(data, dict) and "error" in data:
        return json.dumps({
            "error": "Image generated but Meta upload failed",
            "details": data.get("error"),
            "gemini_model": effective_model,
            "prompt": prompt,
        }, indent=2)

    return json.dumps({
        "success": True,
        "account_id": account_id,
        "raw_response": data,
        "gemini_model": effective_model,
        "prompt": prompt,
    }, indent=2)
