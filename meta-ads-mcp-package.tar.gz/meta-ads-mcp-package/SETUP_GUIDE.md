# Meta Ads MCP Server — Руководство по установке и подключению

## Что это

Локальный MCP-сервер для управления рекламными кампаниями Facebook/Meta через AI-агента (Claude Code, Cursor, Windsurf и др.). Предоставляет 41 инструмент для полного управления: кампании, группы объявлений, объявления, креативы, таргетинг, аналитика, генерация изображений через Gemini.

---

## Системные требования

- Python 3.10+ (рекомендуется 3.12)
- pip
- Claude Code CLI (или другой MCP-совместимый клиент)
- Аккаунт Meta Ads (рекламный кабинет Facebook)

---

## Шаг 1: Распаковка

```bash
# Скопируй архив в целевой проект
cp meta-ads-mcp-package.tar.gz /path/to/your/project/
cd /path/to/your/project/

# Распакуй
tar xzf meta-ads-mcp-package.tar.gz

# Сервер будет в папке meta-ads-mcp/
cd meta-ads-mcp/
```

---

## Шаг 2: Создание виртуального окружения и установка зависимостей

```bash
# Создай виртуальное окружение
python3 -m venv .venv

# Активируй
source .venv/bin/activate

# Установи зависимости
pip install -e .
```

После установки появится исполняемый файл `.venv/bin/meta-ads-mcp`.

---

## Шаг 3: Аутентификация Meta API

### Вариант A: Через Pipeboard.co (рекомендуется, проще всего)

1. Зарегистрируйся на https://pipeboard.co
2. Получи API-токен на https://pipeboard.co/api-tokens
3. Установи переменную:
```bash
export PIPEBOARD_API_TOKEN="pk_live_YOUR_TOKEN"
```

### Вариант B: Через собственное Meta App (полный контроль)

1. Зайди на https://developers.facebook.com
2. Создай приложение (тип: Business)
3. Добавь продукт "Marketing API"
4. Запомни App ID
5. Запусти аутентификацию:
```bash
source .venv/bin/activate
python -m meta_ads_mcp --login --app-id YOUR_APP_ID
```
6. Откроется браузер, авторизуйся через Facebook
7. Токен сохранится в `~/.config/meta-ads-mcp/`

### Вариант C: Прямой токен (если уже есть)

Если у тебя уже есть long-lived access token:
```bash
export META_ACCESS_TOKEN="YOUR_LONG_LIVED_TOKEN"
```

---

## Шаг 4: Подключение к Claude Code

### Регистрация MCP-сервера

```bash
# С App ID (вариант B):
claude mcp add meta-ads-local \
  /ABSOLUTE/PATH/TO/meta-ads-mcp/.venv/bin/meta-ads-mcp \
  --app-id YOUR_META_APP_ID

# С Pipeboard (вариант A):
claude mcp add meta-ads-local \
  -e PIPEBOARD_API_TOKEN=pk_live_YOUR_TOKEN \
  -- /ABSOLUTE/PATH/TO/meta-ads-mcp/.venv/bin/meta-ads-mcp

# С прямым токеном (вариант C):
claude mcp add meta-ads-local \
  -e META_ACCESS_TOKEN=YOUR_TOKEN \
  -- /ABSOLUTE/PATH/TO/meta-ads-mcp/.venv/bin/meta-ads-mcp
```

**ВАЖНО**: Используй абсолютные пути! Например:
```bash
claude mcp add meta-ads-local \
  /home/user/projects/myproject/meta-ads-mcp/.venv/bin/meta-ads-mcp \
  --app-id 1390634508995767
```

### Проверка подключения

```bash
claude mcp list
# Должно показать: meta-ads-local: ... - ✓ Connected
```

---

## Шаг 5 (опционально): Генерация изображений через Gemini

Для использования инструментов `generate_image` и `generate_and_upload_ad_image`:

1. Получи API-ключ Google Gemini: https://aistudio.google.com/apikey
2. Добавь в окружение:
```bash
export GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
```
3. Или при регистрации MCP:
```bash
claude mcp add meta-ads-local \
  -e GEMINI_API_KEY=YOUR_KEY \
  -- /path/to/meta-ads-mcp/.venv/bin/meta-ads-mcp --app-id YOUR_APP_ID
```

---

## Шаг 6 (опционально): HTTP-транспорт

Если нужен HTTP-сервер (например, для веб-интеграции):

```bash
source .venv/bin/activate
python -m meta_ads_mcp --transport streamable-http --host 0.0.0.0 --port 8080
```

Эндпоинт: `POST http://localhost:8080/mcp` (JSON-RPC 2.0)

Подключение через Claude Code:
```bash
claude mcp add --transport http meta-ads-http http://localhost:8080/mcp
```

---

## Доступные инструменты (41 шт.)

### Аккаунты
| Инструмент | Описание |
|---|---|
| `get_ad_accounts` | Список рекламных аккаунтов |
| `get_account_info` | Информация об аккаунте (статус, баланс, таймзона) |
| `get_account_pages` | Facebook Pages, привязанные к аккаунту |
| `search_pages_by_name` | Поиск Pages по названию |

### Кампании
| Инструмент | Описание |
|---|---|
| `get_campaigns` | Список кампаний (фильтр по статусу/цели) |
| `get_campaign_details` | Детали кампании |
| `create_campaign` | Создать кампанию |
| `update_campaign` | Обновить кампанию (название, статус, бюджет) |

### Группы объявлений (Ad Sets)
| Инструмент | Описание |
|---|---|
| `get_adsets` | Список групп объявлений |
| `get_adset_details` | Детали группы |
| `create_adset` | Создать группу с таргетингом и бюджетом |
| `update_adset` | Обновить группу |

### Объявления и креативы
| Инструмент | Описание |
|---|---|
| `get_ads` | Список объявлений |
| `get_ad_details` | Детали объявления |
| `create_ad` | Создать объявление |
| `update_ad` | Обновить объявление |
| `get_ad_creatives` | Получить креатив объявления |
| `create_ad_creative` | Создать креатив (single/FLEX/dynamic) |
| `update_ad_creative` | Обновить креатив |
| `get_ad_image` | Скачать изображение объявления |
| `upload_ad_image` | Загрузить изображение в аккаунт |
| `upload_ad_video` | Загрузить видео (файл или URL) |

### Аналитика
| Инструмент | Описание |
|---|---|
| `get_insights` | Метрики: показы, клики, расход, конверсии, ROAS |

### Таргетинг
| Инструмент | Описание |
|---|---|
| `search_interests` | Поиск интересов по ключевому слову |
| `get_interest_suggestions` | Похожие интересы |
| `estimate_audience_size` | Оценка размера аудитории |
| `search_behaviors` | Поведенческий таргетинг |
| `search_demographics` | Демографический таргетинг |
| `search_geo_locations` | Поиск геолокаций |

### Бюджет и расписание
| Инструмент | Описание |
|---|---|
| `create_budget_schedule` | Расписание бюджета на пиковые периоды |

### Генерация изображений (Gemini)
| Инструмент | Описание |
|---|---|
| `generate_image` | Сгенерировать изображение через Gemini |
| `generate_and_upload_ad_image` | Сгенерировать + загрузить в Meta Ads |

### Поиск
| Инструмент | Описание |
|---|---|
| `search` | Поиск информации |
| `fetch` | Загрузка контента по URL |
| `search_ads_archive` | Поиск в библиотеке рекламы Facebook |

---

## Примеры использования в Claude Code

После подключения MCP-сервера, просто попроси Claude:

```
Покажи мне все кампании в моем рекламном аккаунте act_XXXXX

Создай новую кампанию для трафика с дневным бюджетом $20

Какие метрики у кампании 120240065599770366 за последние 7 дней?

Найди интересы, связанные с "french language learning"

Оцени размер аудитории: женщины 25-45, Украина, интерес к изучению языков

Сгенерируй изображение для рекламы курсов французского языка
```

---

## Устранение неполадок

### MCP не подключается
```bash
# Проверь, что .venv создан и зависимости установлены
ls meta-ads-mcp/.venv/bin/meta-ads-mcp

# Проверь вручную
cd meta-ads-mcp && source .venv/bin/activate && python -m meta_ads_mcp --help
```

### Ошибка аутентификации
```bash
# Перелогинься
source .venv/bin/activate
python -m meta_ads_mcp --login --app-id YOUR_APP_ID
```

### Token expired
Токены Meta живут ~60 дней. При истечении:
```bash
python -m meta_ads_mcp --login --app-id YOUR_APP_ID
```

### Проверка доступных аккаунтов
После подключения попроси Claude: `Покажи список моих рекламных аккаунтов`

---

## Структура файлов

```
meta-ads-mcp/
├── meta_ads_mcp/              # Основной Python-пакет
│   ├── __init__.py
│   ├── __main__.py            # Точка входа
│   └── core/
│       ├── server.py          # FastMCP сервер
│       ├── api.py             # Graph API клиент
│       ├── auth.py            # OAuth аутентификация
│       ├── accounts.py        # Инструменты аккаунтов
│       ├── campaigns.py       # Кампании
│       ├── adsets.py          # Группы объявлений
│       ├── ads.py             # Объявления и креативы
│       ├── insights.py        # Аналитика
│       ├── targeting.py       # Таргетинг
│       ├── gemini_images.py   # Генерация изображений
│       └── ...
├── requirements.txt           # Зависимости (pip)
├── pyproject.toml             # Метаданные проекта
├── setup.py                   # Установка
└── SETUP_GUIDE.md             # Эта инструкция
```

---

## Лицензия

BUSL-1.1 (Business Source License). Для коммерческого использования ознакомься с условиями в `pyproject.toml`.
